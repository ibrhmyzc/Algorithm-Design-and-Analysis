import sys

#Algorithms below led me to the results, I changed them to find what I need to do in homework
#works for only n*r where n=r
#i could not figure out how to return the array
#REFRENCES
#http://www.cplusplus.com/forum/general/73283/
#http://webhome.cs.uvic.ca/~wendym/courses/445/12/1notes/GuomingTang.pdf

def find_which_assistant(inputTable, key, counter):
    #print("key:",key)
    for j in range(len(inputTable[counter])):
        if(inputTable[counter][j] == key):
            #print(inputTable[counter])
            #print("return:", j)
            return j


def per(inputTable, output_array, n, valid_index):
    #if all is occupied already
    if(n >= len(inputTable)):
        return 0, output_array
    # we must find a way smaller than max cost
    max = sys.maxsize
    counter = 0
    index_counter = 0
    while(counter < len(inputTable)):
        for i in range(len(valid_index)):
            if(valid_index[counter]):
                valid_index[counter] = 0
                if (valid_index[i] == 0):
                    index_counter += 1
                temp_value, output_array = per(inputTable, output_array, n + 1, valid_index)
                # output_array[n] = find_which_assistant(row, temp_value, n, i)
                sum = inputTable[n][counter] + temp_value

                if(sum < max):
                    if (index_counter == 0):
                        output_array[counter-1] = find_which_assistant(inputTable, sum - temp_value, counter-1)
                    #print("sum:", sum)
                    max = sum
                valid_index[counter] = 1
                index_counter = 0
        counter += 1

    return max, output_array

def findOptimalAssistantship(inputTable):

    output_array = [-1] * len(inputTable)
    valid_index = [1] * len(inputTable[0])
    nth_assistant = 0
    #i will call the permutation function and calculate the minimum total cost
    if(len(inputTable) == len(inputTable[0])):
        cost, output_array = per(inputTable, output_array, nth_assistant, valid_index)
    else:
        cost = 0
    return output_array, cost

inputTable = [
    [5, 8, 7],
    [8, 12, 7],
    [4, 8, 5],
]

asst, time = findOptimalAssistantship(inputTable)
print(asst)
print(time)
