
def findMinimumCostToLabifyGTU(build, repair, uni):
    number_of_roads = 0
    cost_of_buildings = 0
    cost_of_repairing = 0
    number_of_separate_paths = 1
    covered_list = []

    bfs_result = bfs(uni, 1)

    #if all departments are covered
    if(len(bfs_result) == len(uni)):
        if(build >= repair):
            number_of_roads = len(bfs_result) - 1
            cost_of_repairing = repair * number_of_roads
            cost_of_buildings = number_of_separate_paths * build
            return cost_of_buildings + cost_of_repairing
        else:
            return len(uni) * build
    else:
        if(build >= repair):
            covered_list.append(len(bfs_result))
            number_of_roads += covered_list[0] - 1
            found = 0
            for i in range(len(uni)):
                bfs_result = bfs(uni, i+1)
                covered_department = len(bfs_result)
                for j in range(len(covered_list)):
                    if(covered_department == covered_list[j]):
                        found = 1
                if(found == 0):
                    covered_list.append(covered_department)
                    number_of_separate_paths += 1
                    number_of_roads += covered_department - 1
                    cost_of_buildings = number_of_separate_paths * build
                    cost_of_repairing = repair * number_of_roads
                found = 0
            return cost_of_buildings + cost_of_repairing
        else:
            return len(uni) * build


#http://eddmann.com/posts/depth-first-search-and-breadth-first-search-in-python/
def bfs(gtu_grahp, first_vertex):
    visited_vertices, queue = set(), [first_vertex]
    flag = 0
    while((len(queue) > 0)):
        if(len(queue)):
            current_vertex = queue.pop(0)
        else:
            return visited_vertices

        if current_vertex not in visited_vertices:
            flag = 1
        if(flag == 1):
            visited_vertices.add(current_vertex)
            #print("current vetex:", current_vertex)
            queue.extend(gtu_grahp[current_vertex] - visited_vertices)
        flag = 0
    return visited_vertices



mapOfGTU2 = {
    1 : set([2, 3]),
    2 : set([1, 3, 4]),
    3 : set([1, 2, 4]),
    4 : set([3, 2]),
    5 : set([6]),
    6 : set([5]),
}
mapOfGTU = {
    1 : set([2, 3]),
    2 : set([1, 3]),
    3 : set([1, 2])
}
minCost = findMinimumCostToLabifyGTU(5, 2, mapOfGTU2)
print(minCost)

