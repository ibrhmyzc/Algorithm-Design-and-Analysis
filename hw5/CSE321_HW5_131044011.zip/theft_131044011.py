def theft(land):
    # Storing row and column numbers
    number_of_rows = len(land)
    number_of_columns = len(land[0])
    # keeping the maximum money
    results = [0] * number_of_rows

    # Creating an matrix with the same size as the input matrix in order to keep calculated values
    collected_money = [[0 for x in range(number_of_rows)] for x in range(number_of_columns)]
    flagged = [[True for x in range(number_of_rows)] for x in range(number_of_columns)]

    for start_point in range(number_of_rows):
        collected_money[start_point][0] = land[start_point][0]

        counter = 1
        for k in range(start_point + 1, number_of_rows, 1):
            for l in range(counter):
                # print(k, l)
                collected_money[k][l] = land[k][l]
                flagged[k][l] = False
            counter += 1

        counter = 1
        if start_point > 0:
            for k in range(start_point - 1, -1, -1):
                for l in range(counter):
                    # print(k, l)
                    collected_money[k][l] = land[k][l]
                    flagged[k][l] = False
                counter += 1

        flagged[start_point][0] = True

        # Calculating the paths
        for j in range(number_of_columns):
            for i in range(number_of_rows):
                collected_money[start_point][0] = land[start_point][0]
                # print(i, j)
                if flagged[i][j]:
                    # print(i, j)
                    # For right move
                    if legal_move(i, j - 1, number_of_rows, number_of_columns) and flagged[i][j-1]:
                        right = collected_money[i][j - 1]
                    else:
                        right = -1

                    # For right_up move
                    if legal_move(i + 1, j - 1, number_of_rows, number_of_columns) and flagged[i + 1][j-1]:
                        right_up = collected_money[i + 1][j - 1]
                    else:
                        right_up = -1

                    # For right_down move
                    if legal_move(i - 1, j - 1, number_of_rows, number_of_columns) and flagged[i - 1][j-1]:
                        right_down = collected_money[i - 1][j - 1]
                    else:
                        right_down = -1

                    max_direction = max(right, right_up, right_down)
                    if max_direction != -1:
                        # if i == 0 and j == 2 and start_point == 2:
                            # print(i, j)
                            # print(right, right_up, right_down)
                        collected_money[i][j] = max_direction + land[i][j]

        if start_point == 0:
            collected_money[0][number_of_columns - 1] = land[0][number_of_columns - 1] + max(collected_money[0][number_of_columns - 2], collected_money[1][number_of_columns - 2])


        # print(flagged)
        # print(collected_money)

        # Finding the maximum money for this starting index
        local_max = collected_money[0][number_of_columns - 1]
        for k in range(number_of_rows):
            if local_max < collected_money[0][i]:
                local_max = collected_money[0][i]
        results[start_point] = local_max

        # Reset their values for next starting point
        collected_money = [[0 for x in range(number_of_rows)] for x in range(number_of_columns)]
        flagged = [[True for x in range(number_of_rows)] for x in range(number_of_columns)]
    results.sort()
    return results[len(results) - 1]


def legal_move(i, j, row, column):
    if i < row and j < column and i >=0 and j >= 0:
        return True
    else:
        return False

amountOfMoneyInLand= [[1,3,1,5], [2,2,4,1], [5,0,2,3], [0,6,1,2]]
res = theft(amountOfMoneyInLand)
print(res)
#Output: 16
amountOfMoneyInLand= [[10,33,13,15], [22,21,4,1], [5,0,2,3], [0,6,14,2]]
res = theft(amountOfMoneyInLand)
print(res)
Output: 83
