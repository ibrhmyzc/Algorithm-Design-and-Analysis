def find_maximum_cost(y):
    x = [] * len(y)

    if y[2] == 1:
        if abs(y[1] - 1) * 2 > y[0]:
            x.append(1)
            x.append(y[1])
        else:
            x.append(y[0])
            x.append(1)
    else:
        if y[0] == 1:
            x.append(y[0])
            x.append(y[1])
        else:
            x.append(y[0])
            x.append(1)

    for i in range(2, len(y), 1):
        # print(y[i], "***************")
        if y[i] == 1:
            x.append(1)
        else:
            local_max = 1
            local_max_index = 1
            for j in range(1, y[i] + 1, 1):
                previous = x[i - 1]
                if local_max < abs(previous - j):
                    local_max = abs(previous - j)
                    local_max_index = j
            x.append(local_max_index)
    print(y)
    print(x)
    if len(x) != len(y):
        print("error array size")
    res = value_finder(x, 0)
    return res


def value_finder(x, start):
    result = 0
    # print("current x length", len(x))
    if len(x) == 1:
        return x[0]
    elif len(x) == 2:
        return x[1] - x[0]
    else:
        for i in range(start, len(x) - 1, 1):
            tmp = abs(x[i + 1] - x[i])
            result += tmp
        return result

print("**************************")
Y = [14,1,14,1,14]
cost = find_maximum_cost(Y)
print(cost)
#Output: 52
print("**************************")
Y = [1,9,11,7,3]
cost = find_maximum_cost(Y)
print(cost)
#Output: 28
print("**************************")
Y = [50,28,1,1,13,7]
cost = find_maximum_cost(Y)
print(cost)
# Output: 78
print("**************************")
Y = [80 ,22 ,45 ,11 ,67 ,67 ,74 ,91 ,4 ,35 ,34 ,65 ,80 ,21 ,95 ,1 ,52 ,25 ,31 ,2 ,53]
cost = find_maximum_cost(Y)
print(cost)
#Output: 1107
print("**************************")
Y = [79 ,6 ,40 ,68 ,68 ,16 ,40 ,63 ,93 ,49 ,91]
cost = find_maximum_cost(Y)
print(cost)
#Output: 642
