def compareScales (leftScaleList, rightScaleList):
    result = sum(leftScaleList) - sum(rightScaleList)
    if result < 0:
        return 1
    elif result > 0:
        return -1
    else:
        return 0


def findRotten(input_list):
    #in case it if it an odd number
    if len(input_list) % 2 == 1 and len(input_list) > 2:
        temp = input_list[len(input_list) // 2]
        if temp < input_list[0]:
            return len(input_list) // 2
        else:
            if (compareScales(input_list[:len(input_list) // 2], input_list[(len(input_list)+1) // 2:])) == -1:
                return len(input_list) // 2 + 1 + findRotten(input_list[(len(input_list)+1) // 2:])
            elif (compareScales(input_list[:len(input_list) // 2], input_list[(len(input_list)+1) // 2:])) == 1:
                return findRotten(input_list[:len(input_list) // 2])
            else:
                return -1

    # in case it if it an even number
    if len(input_list) % 2 == 0 and len(input_list) > 2:
        if (compareScales(input_list[:len(input_list)//2], input_list[len(input_list)//2:])) == 0:
            return -1
    if len(input_list) == 0:
        return 0
    elif (compareScales(input_list[:len(input_list)//2], input_list[len(input_list)//2:])) == -1:
        return len(input_list)//2 + findRotten(input_list[len(input_list)//2:])
    else:
        return findRotten(input_list[:len(input_list)//2])


print ("TEST CASES")

initial_list = [1, 1, 1, 1, 1, 1, 1]
print (initial_list)
print (findRotten(initial_list))

initial_list = [1, 1, 1, 0.5, 1, 1, 1]
print (initial_list)
print (findRotten(initial_list))

initial_list = [1, 1, 1, 1, 1, 1]
print (initial_list)
print (findRotten(initial_list))

initial_list = [1, 1, 1, 1, 1, 1, 0.5]
print (initial_list)
print (findRotten(initial_list))

initial_list = [1, 1, 1, 1, 0.5, 1]
print (initial_list)
print (findRotten(initial_list))

initial_list = [1, 0.5]
print (initial_list)
print (findRotten(initial_list))

initial_list = [0.5, 1]
print (initial_list)
print (findRotten(initial_list))

initial_list = [0.5, 1, 1]
print (initial_list)
print (findRotten(initial_list))

initial_list = [1, 1, 1, 0.5]
print (initial_list)
print (findRotten(initial_list))

initial_list = [1, 1, 1, 1, 0.5, 1, 1, 1, 1]
print (initial_list)
print (findRotten(initial_list))