#im using the tower of hanoi function(only to print moves) that we were shown in the CLASSROOM
#so it may look similar to other students code
#if we were not supposed to use this please grade me for the time calculation part only
# adding the time calculation feature by myself
def toh (initial_pos, final_pos, temp, number_of_disk):
    if number_of_disk == 1:
        print ("disk 1 :",initial_pos," to ",final_pos)
        if initial_pos == "SRC" and final_pos == "DST":
            time_for_disk[0] += 4
        else:
            time_for_disk[0] += 2
        return
    else:
        toh(initial_pos, temp, final_pos, number_of_disk - 1)
        print("disk",number_of_disk,":", initial_pos," to ",final_pos)
        if initial_pos == "SRC" and final_pos == "DST":
            time_for_disk[number_of_disk-1] += 4
        else:
            time_for_disk[number_of_disk-1] += 2
        toh(temp, final_pos, initial_pos, number_of_disk - 1)


#since we were not told i am not getting input from user
#you should change the disk number by simply editting below
disk = 4
#creating an array for disk number
time_for_disk = [0] * disk
print ("Input size is",disk)
toh("SRC", "DST", "AUX", disk)
#printing the elalpsed time for all disks
for i in range(disk):
    print ("Elapsed time for disk",i+1,":",time_for_disk[i])
