# Lomuto's advantage
# Lomuto's is easy to implement compared to Hoare's
# Hoare's advantage
# For already sorted arrays, Hoare's do no swap operation while Lomuto's does about n/2 swaps


# http://homepages.math.uic.edu/~leon/cs-mcs401-s08/handouts/quicksort.pdf
# https://en.wikipedia.org/wiki/Quicksort#Hoare_partition_scheme
# and in the course book, both pseudo codes can be found


def quickSortHoare(arr):
    start = 0
    finish = len(arr) - 1
    main_qsh(arr, start, finish)
    # helper_qsh(arr, start, finish, pivot)
    return arr


def main_qsh(arr, start, finish):
    if start < finish:
        pivot = arr[start]
        temp_start, temp_finish = helper_qsh(arr, start, finish, pivot)
        main_qsh(arr, start, temp_finish)
        main_qsh(arr, temp_start, finish)


def helper_qsh(arr, start, finish, pivot):

    temp_start = start
    temp_finish = finish

    while temp_start <= temp_finish:
        temp_start, temp_finish = temp_value_finder_for_qsh(pivot, temp_start, temp_finish)
        #print("ts:", temp_start, "tf", temp_finish)
        if temp_start <= temp_finish:
            #print("swapping -> ", "ts:", temp_start, "tf", temp_finish)
            temp = arr[temp_start]
            arr[temp_start] = arr[temp_finish]
            arr[temp_finish] = temp
            temp_start += 1
            temp_finish -= 1
            if temp_start <= temp_finish:
                return temp_start, temp_finish
        else:
            temp = arr[start]
            arr[start] = arr[temp_finish]
            arr[temp_finish] = temp
            break

    return temp_start, temp_finish


def temp_value_finder_for_qsh(pivot, temp_start, temp_finish):
    for i in range(temp_start, len(arr)):
        if pivot > arr[i]:
            temp_start += 1
        else:
            break
    for i in range(temp_finish, 0, -1):
        if pivot < arr[i]:
            temp_finish -= 1
        else:
            break
    return temp_start, temp_finish

# http://www.cs.bilkent.edu.tr/~atat/473/lecture05.pdf
# https://en.wikipedia.org/wiki/Quicksort#Lomuto_partition_scheme

def quickSortLomuto(arr):
    start = 0
    finish = len(arr) - 1
    main_qsl(arr, start, finish)
    return arr


def main_qsl(arr, start, finish):
    if start < finish:
        pivot = arr[finish]
        temp = helper_qsl(arr, start, finish, pivot)
        main_qsl(arr, start, temp - 1)
        main_qsl(arr, temp + 1, finish)


def helper_qsl(arr, start, finish, pivot):
    # print("*******************")
    # print(arr)
    # print("pivot =", pivot, start, finish)
    res = start - 1
    temp_length = finish - start
    # print(temp_lenght)
    if temp_length == 0:
        return start
    elif temp_length == 1:
        if arr[start] > arr[finish]:
            # print("3.swap", arr[finish], arr[start])
            temp = arr[start]
            arr[start] = arr[finish]
            arr[finish] = temp
            res += 1
            return res
        else:
            return start
    else:
        for i in range(start, finish + 1, 1):
            if i == finish:
                # print("2.swap", arr[finish], arr[res + 1])
                temp = arr[res + 1]
                arr[res + 1] = arr[finish]
                arr[finish] = temp
                res += 1
                return res
            if arr[i] <= pivot:
                res += 1
                # print("1.swap", arr[i], arr[res])
                temp = arr[res]
                arr[res] = arr[i]
                arr[i] = temp


arr = [15,4,68,24,75,16,42]
qsh = quickSortHoare(arr)
print(qsh)
arr = [15,4,68,24,75,16,42]
qsl = quickSortLomuto(arr)
print(qsl)

