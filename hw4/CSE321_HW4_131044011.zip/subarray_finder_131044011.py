import sys

# http://web.cs.ucdavis.edu/~bai/ECS122A/Maxsubarray.pdf
# https://en.wikipedia.org/wiki/Maximum_subarray_problem#Algorithm_2:_Divide_and_Conquer
# I used the algorithm in the link above and alter it in order to put it work for minimum sub array
# and return the minimum sub array as an array
# To do this, I first multiply all the element of the array by -1. Now we can simply use the algorithm
# I divide the array into 2 arrays recursively and keep doing this for both sides of the array
# For left side I start counting from right, for right side is vice versa. I store them in an array index after final
# step in order to find the resulting array where i also find the minimum subarray sum
# Worst case scenario is where the result array's lenght is len(inp) - 1
# , because if all is negative, i do it in constant time
# I could not solve some bugs in my code. But most of the time it works


def min_subarray_finder(inpArr):
    # if the array has only one element
    if len(inpArr) == 0:
        return 0
    begin = 0
    end = len(inpArr) - 1

    check = True
    for i in range(end + 1):
        if inpArr[i] > 0:
            check = False

    if check == True:
        return inpArr

    check = True
    c = 0
    for i in range(end + 1):
        if inpArr[i] >= 0:
            c += 1
    if c == end + 1:
        return []
    # Multiple all indexed by -1
    for i in range(len(inpArr)):
        inpArr[i] *= -1

    # Store minimum contiguous array
    outArr = []
    indexArray = []
    result = -1 * min_sub_array(inpArr, begin, end, outArr, 0, indexArray)
    #print("result:", result)


    #Here i try to complete the result array
    final_result = []
    # print(indexArray)

    if len(indexArray) == 0 and inpArr[end] > 0:
        final_result.append(-1 * inpArr[end])
        return final_result

    smallest_index = indexArray[0]
    largest_index = indexArray[0]
    for i in range(len(indexArray)):
        if indexArray[i] < smallest_index:
            smallest_index = indexArray[i]
        elif indexArray[i] > largest_index:
            largest_index = indexArray[i]
    #print(smallest_index, largest_index)

    if smallest_index == 1 and inpArr[smallest_index - 1] > 0:
        final_result.append(-1 * inpArr[0])
    elif smallest_index >= 1 and inpArr[0] > 0:
        c_to_s = 0
        for i in range(len(indexArray) - 2):
            c_to_s += indexArray[indexArray[i + 1]]
        if c_to_s < inpArr[0]:
            for i in range(0, smallest_index, 1):
                final_result.append(-1 * inpArr[i])

    for i in range(smallest_index, largest_index + 1, 1):
        final_result.append(-1 * inpArr[i])

    return final_result


def min_sub_array(inpArr, start, finish, outArr, counter, indexArray):
    if start == finish:
        return inpArr[start]

    mid = (start + finish) // 2
    # print("mid: ", mid)
    # print("(",start, mid, finish, ")")
    left_sub_array = min_sub_array(inpArr, start, mid, outArr, counter + 1, indexArray)
    right_sub_array = min_sub_array(inpArr, mid + 1, finish, outArr, counter + 1, indexArray)

    if finish % 2 == 1:
        right_sum = find_subarray_sum(inpArr, mid, finish, "right", outArr, counter, indexArray)
        left_sum = find_subarray_sum(inpArr, start, mid, "left", outArr, counter, indexArray)
    else:
        left_sum = find_subarray_sum(inpArr, start, mid, "left", outArr, counter, indexArray)
        right_sum = find_subarray_sum(inpArr, mid, finish, "right", outArr, counter, indexArray)

    total_sum = left_sum + right_sum
    # print("total sum:", total_sum, "left:", left_sum, "right:", right_sum)

    if left_sub_array < right_sub_array:
        if total_sum < right_sub_array:
            return right_sub_array
        else:
            return total_sum
    else:
        if total_sum < left_sub_array:
            return left_sub_array
        else:
            return total_sum


def find_subarray_sum(inpArr, start, finish, side, outArr, counter, indexArray):
    #print(side, start, finish)
    #print("counter:", counter)
    if side == "left":
        # print("left")
        sum_side = 0
        result = 0
        for i in range(finish, start, -1):
            sum_side += inpArr[i]
            if sum_side > result:
                if counter == 0:
                    # print(i)
                    outArr.append(-1 * inpArr[i])
                    indexArray.append(i)
                #print(inpArr[i])
                result = sum_side
        # print("res:", result)
    else:
        # print("right")
        sum_side = 0
        result = 0
        for i in range(start + 1, finish + 1):
            sum_side += inpArr[i]
            if sum_side > result:
                if counter == 0:
                    # print(i)
                    outArr.append(-1 * inpArr[i])
                    indexArray.append(i)
                result = sum_side
        # print("res:", result)
    # print("*********************")

    return result



inpArr = [1, -4, -7, 5, -13, 9, 23, -1]
msa = min_subarray_finder(inpArr)
print(msa)
#Output: [-4, -7, 5, -13]
print(sum(msa))
#Output: -19

