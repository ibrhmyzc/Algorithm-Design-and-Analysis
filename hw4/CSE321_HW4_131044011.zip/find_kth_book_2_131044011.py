# This time we don't divide the arrays by their size and compare their midpoints
# we divide them and compare them for k/2th element


def find_kth_book_2(m, n, k):
    if k == 1:
        if m[0] < n[0]:
            return m[0]
        else:
            return n[0]
    elif k == len(m) + len(n):
        if m[len(m) - 1] > n[len(n) - 1]:
            return m[len(m) - 1]
        else:
            return n[len(n) - 1]
    else:
        return "no answer"

m = ["algotihm", "programminglanguages", "systemsprogramming"]
n = ["computergraphics", "cprogramming","oop"]
book = find_kth_book_2(m,n,4)
print(book)
book = find_kth_book_2(m,n,6)
print(book)
