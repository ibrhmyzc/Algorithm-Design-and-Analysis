# I kept dividing the two sorted arrays by 2 . After each step, I compared both of their middle points
# in order to find what sides of which array should be eliminated. So there are two binary searches to find kth
# element, the complexity is O(logm + logn) where m=len(m) n=len(n)
# Worst Case Scenario 1: When it is located in the beginning or the ending of the array
# Worst Case Scenario 2: But in my implementation finding the smallest and the biggest elements is O(1). So
# elements next to them are the worst case scenario


def find_kth_book_1(m, n, k):
    start_m = 0
    start_n = 0
    finish_m = len(m) - 1
    finish_n = len(n) - 1
    # if we are looking for the smallest element
    if k == 1:
        if m[0] > n[0]:
            return n[0]
        else:
            return m[0]
    k = k - 1
    result = kth_book(m, n, start_m, start_n, finish_m, finish_n, k)

    return result


def kth_book(m, n, start_m, start_n, finish_m, finish_n, k):
    # print("--------------")
    # print(start_m, finish_m, start_n, finish_n, "k =", k, "->", start_m + k, start_n + k)
    if k > len(m) + len(n):
        return "invalid k"

    if k == len(m) + len(n) - 1:
        if m[len(m) - 1] > n[len(n) - 1]:
            return m[len(m) - 1]
        else:
            return n[len(n) - 1]

    if k < 1 and (start_m > finish_m or start_n > finish_n):
        # print("k < 1 :", start_m, finish_m, start_n, finish_n, k, "->", start_m + k, start_n + k)
        if start_m + k >= len(m):
            return n[start_n + k]
        elif start_n + k >= len(n):
            return m[start_m + k]
        if m[start_m + k] < n[start_n + k]:
            return m[start_m + k]
        else:
            return n[start_n + k]

    if start_m > finish_m :
        # print("n", start_m, finish_m, start_n, finish_n, k, "->", start_n + k)
        # if start_n + k >= len(n):
        #     return "out of index n"
        return n[start_n + k]
    elif start_n > finish_n :
        # print("m", start_m, finish_m, start_n, finish_n, k, "->", start_m + k)
        # if start_m + k >= len(m):
        #     return "out of index m"
        return m[start_m + k]

    # first we find the middle points of the remaining arrays
    middle_of_m = ((finish_m + start_m) // 2)
    middle_of_n = ((finish_n + start_n) // 2)

    mid_value_m = m[middle_of_m]
    mid_value_n = n[middle_of_n]

    # print("mid_m =", middle_of_m, "mid_n =", middle_of_n, "k =", k)
    # print(start_m, finish_m, start_n, finish_n)
    # here we find out if we should eliminate from left or right side of middle point
    which_side_gets_eliminated = middle_of_m + middle_of_n - start_m - start_n
    # print("cmp", which_side_gets_eliminated, k)
    if which_side_gets_eliminated >= k:
        eliminate = "left"
    else:
        eliminate = "right"

    if mid_value_m >= mid_value_n:
        if eliminate == "left":
            finish_m = middle_of_m - 1
            return kth_book(m, n, start_m, start_n, finish_m, finish_n, k)
        else:
            k = k + start_n - middle_of_n - 1
            start_n = middle_of_n + 1
            return kth_book(m, n, start_m, start_n, finish_m, finish_n, k)
    else:
        if eliminate == "left":
            finish_n = middle_of_n - 1
            return kth_book(m, n, start_m, start_n, finish_m, finish_n, k)
        else:
            k = k + start_m - middle_of_m - 1
            start_m = middle_of_m + 1
            return kth_book(m, n, start_m, start_n, finish_m, finish_n, k)


m = ["algotihm", "programminglanguages", "systemsprogramming"]
n = ["computergraphics", "cprogramming","oop"]

book = find_kth_book_1(m,n,4)
print(book)
book = find_kth_book_1(m,n,6)
print(book)


# for i in range(len(m) + len(n)):
#     book = find_kth_book_1(m,n,i+1)
#     print(i+1, book)

